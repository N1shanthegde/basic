﻿namespace WebApplication2.Dtos
{
    public class AdminDashboardDto
    {
        public int TotalOrders { get; set; }
        public int TotalProducts { get; set; }
        public int TotalUsers { get; set; }
    }
}
