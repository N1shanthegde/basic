﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.DTOs;
using WebApplication1.Data;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public UserController(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _context.Users.ToListAsync();
            return Ok(users);
        }

        [HttpGet("{id:guid}")]
        [Authorize]
        public async Task<IActionResult> GetUserProfile(Guid id)
        {
            var user = await _context.Users.FindAsync(id.ToString());
            if (user == null) return NotFound("User not found.");
            return Ok(_mapper.Map<UserProfileDto>(user));
        }

        [HttpPut("{id:Guid}")]
        [Authorize(Roles = "User, Admin")]
        public async Task<IActionResult> UpdateUserProfile(Guid id, UpdateUserProfileDto updateDto)
        {
            var user = await _context.Users.FindAsync(id.ToString());
            if (user == null) return NotFound("User not found");

            _mapper.Map(updateDto, user);
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return NoContent();

        }

        [HttpPost("changePassword")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> ChangePassword([FromBody]ChangePasswordDto changePasswordDto)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
                return Unauthorized("User ID not found in token.");

            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound("User not found");

            var passwordHasher = new PasswordHasher<ApplicationUser>();

            var result = passwordHasher.VerifyHashedPassword(user, user.PasswordHash, changePasswordDto.OldPassword);
            if (result == PasswordVerificationResult.Failed)
                return BadRequest("Old password is incorrect.");

            user.PasswordHash = passwordHasher.HashPassword(user, changePasswordDto.NewPassword);
            if (string.IsNullOrEmpty(user.PasswordHash))
                return BadRequest("User does not have a password set.");

            _context.Users.Update(user);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error saving changes: {ex.Message}");
            }

            return NoContent();
        }


        [HttpGet("Dashboard")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetDashboard()
        {
            var totalOrders =  _context.Orders.Count();
            var totalProducts =  _context.Products.Count();
            var totalUsers = _context.Users.Count();

            return Ok(new 
            {
                TotalOrders = totalOrders,
                TotalProducts = totalProducts,
                TotalUsers = totalUsers
            });
        }

    }
}
