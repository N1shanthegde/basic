﻿namespace WebApplication1.DTOs
{
    public class LoginResponseDto
    {
        public string JwtToken { get; set; }
    }
}
