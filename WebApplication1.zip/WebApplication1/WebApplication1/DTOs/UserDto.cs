﻿namespace WebApplication1.DTOs
{
    public class UserProfileDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
    }


    public class UpdateUserProfileDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }

    public class ChangePasswordDto
    {
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }
}
